import streamlit as st
from ui_components import setup_page, hero, kpi_card, load_report, fmt_number, chart_title, insight, bar_chart, section_card

setup_page("Operational Impact")
hero("Operational Impact", "Incident and downtime view showing how lifecycle status connects to business disruption.")

ops = load_report("operational_impact_by_lifecycle_status.csv")
inc = load_report("incident_downtime_by_lifecycle.csv")
if inc.empty:
    inc = ops.copy()

incidents = fmt_number(ops["incidents"].sum()) if not ops.empty and "incidents" in ops.columns else "—"
downtime = fmt_number(ops["downtime_hours"].sum()) if not ops.empty and "downtime_hours" in ops.columns else "—"
rate = "—"
if not ops.empty and "incident_rate_per_asset" in ops.columns:
    rate = f"{ops['incident_rate_per_asset'].max():.2f}"
status = str(ops.sort_values("downtime_hours", ascending=False).iloc[0]["Lifecycle_Status"]) if not ops.empty and "downtime_hours" in ops.columns else "—"
cols = st.columns(4)
with cols[0]: kpi_card("Total Incidents", incidents, "Incidents tied to managed assets", "●", "blue")
with cols[1]: kpi_card("Downtime Hours", downtime, "Operational disruption measured in hours", "◴", "amber")
with cols[2]: kpi_card("Highest Rate", rate, "Max incidents per asset", "▲", "red")
with cols[3]: kpi_card("Highest Impact", status, "Lifecycle group with highest downtime", "⚠", "purple")

section_card("Executive Interpretation", "Operational impact converts lifecycle exposure into business language. If unsupported assets create more incidents or downtime, refresh planning becomes an operational resilience issue rather than an infrastructure maintenance task.")

if not ops.empty:
    chart_title("Downtime by Lifecycle Status")
    insight("Compares downtime across lifecycle groups. Higher downtime in unsupported or near-EOL assets strengthens the case for targeted refresh investment.")
    bar_chart(ops, x="downtime_hours", y="Lifecycle_Status", height=360)
    chart_title("Incident Rate by Lifecycle Status")
    insight("Shows how often assets generate incidents in each lifecycle group. This helps leaders understand whether older assets create more support demand.")
    bar_chart(ops, x="incident_rate_per_asset", y="Lifecycle_Status", height=360)
