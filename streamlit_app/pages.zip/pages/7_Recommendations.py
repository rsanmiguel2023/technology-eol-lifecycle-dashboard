import streamlit as st
from ui_components import setup_page, hero, kpi_card, load_report, section_card

setup_page("Recommendations")
hero("Recommendations", "Prioritized actions for reducing lifecycle, cyber, compliance, funding, and operational risk.")

rec = load_report("recommendation_actions.csv")

cols = st.columns(4)
with cols[0]: kpi_card("Immediate", "0–6M", "Remediate critical exposure", "⚠", "red")
with cols[1]: kpi_card("Near Term", "6–12M", "Fund refresh waves", "$", "green")
with cols[2]: kpi_card("Medium Term", "12–24M", "Reduce unsupported footprint", "↻", "orange")
with cols[3]: kpi_card("Ongoing", "Quarterly", "Governance and exception tracking", "◎", "blue")

section_card("Executive Recommendation", "Technology lifecycle risk should be governed as a recurring enterprise risk program. The bank should prioritize assets that combine unsupported status, vulnerability exposure, operational downtime, and high business criticality.")

if not rec.empty:
    for _, row in rec.iterrows():
        section_card(
            f"Priority {row.get('priority', '')}: {row.get('action', '')}",
            f"<p><strong>Owner:</strong> {row.get('owner','')}</p>"
            f"<p><strong>Timeframe:</strong> {row.get('timeframe','')}</p>"
            f"<p><strong>Rationale:</strong> {row.get('rationale','')}</p>"
            f"<p><strong>Expected outcome:</strong> {row.get('expected_outcome','')}</p>"
        )
else:
    st.info("Run executive reporting to generate recommendations.")
