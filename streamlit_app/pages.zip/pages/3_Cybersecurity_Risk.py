import streamlit as st
from ui_components import setup_page, hero, kpi_card, load_report, fmt_number, fmt_money, chart_title, insight, bar_chart, topn, section_card

setup_page("Cybersecurity Risk")
hero("Cybersecurity Risk", "View of unsupported and near-EOL assets with critical or high vulnerability exposure.")

cyber = load_report("cybersecurity_unsupported_critical_summary.csv")
assets = load_report("past_eol_critical_vulnerability_assets.csv")

affected = fmt_number(cyber["assets"].sum()) if not cyber.empty and "assets" in cyber.columns else "—"
crit = fmt_number(cyber["critical_vulns"].sum()) if not cyber.empty and "critical_vulns" in cyber.columns else "—"
high = fmt_number(cyber["high_vulns"].sum()) if not cyber.empty and "high_vulns" in cyber.columns else "—"
cost = fmt_money(cyber["replacement_cost"].sum()) if not cyber.empty and "replacement_cost" in cyber.columns else "—"
cols = st.columns(4)
with cols[0]: kpi_card("Exposed Assets", affected, "Unsupported assets with cyber exposure", "△", "red")
with cols[1]: kpi_card("Critical Findings", crit, "Critical vulnerability count", "!", "red")
with cols[2]: kpi_card("High Findings", high, "High severity vulnerability count", "▲", "orange")
with cols[3]: kpi_card("Replacement Exposure", cost, "Cost tied to exposed assets", "$", "green")

section_card("Executive Interpretation", "Cybersecurity exposure is most urgent when unsupported assets also carry critical or high vulnerabilities. These systems have a smaller remediation window, weaker vendor support options, and higher operational risk if compensating controls are not in place.")

if not cyber.empty:
    agg = cyber.groupby("Business_Unit", as_index=False).agg(assets=("assets", "sum"), critical_vulns=("critical_vulns", "sum"), high_vulns=("high_vulns", "sum"))
    agg["total_findings"] = agg["critical_vulns"] + agg["high_vulns"]
    chart_title("Cyber Exposure by Business Unit")
    insight("Ranks business units by unsupported assets with critical or high vulnerability exposure. This identifies where security remediation and lifecycle refresh should be coordinated.", alert=True)
    bar_chart(topn(agg, "total_findings", 10), x="total_findings", y="Business_Unit", height=410)
if not assets.empty:
    agg2 = assets.groupby("Asset_Type", as_index=False).agg(assets=("Asset_ID", "count"))
    chart_title("Exposed Assets by Technology Type")
    insight("Shows whether vulnerability exposure is concentrated in endpoints or also present across servers, network, VDI, and storage platforms.")
    bar_chart(topn(agg2, "assets", 10), x="assets", y="Asset_Type", height=360)
