import streamlit as st
from ui_components import setup_page, hero, kpi_card, load_report, fmt_number, fmt_money, chart_title, insight, bar_chart, topn, section_card

setup_page("Lifecycle Exposure")
hero("Lifecycle Exposure", "Executive view of unsupported and near-end-of-life technology across business units and asset categories.")

bu = load_report("business_unit_eol_exposure.csv")
by_type = load_report("lifecycle_exposure_by_asset_type.csv")
exec_sum = load_report("executive_lifecycle_summary.csv")

past = fmt_number(bu["past_eol"].sum()) if not bu.empty and "past_eol" in bu.columns else "—"
exp = fmt_number(bu["expiring_12mo"].sum()) if not bu.empty and "expiring_12mo" in bu.columns else "—"
cost = fmt_money(bu["replacement_cost"].sum()) if not bu.empty and "replacement_cost" in bu.columns else "—"
top_bu = str(bu.sort_values("past_eol", ascending=False).iloc[0]["Business_Unit"]) if not bu.empty and "past_eol" in bu.columns else "—"
cols = st.columns(4)
with cols[0]: kpi_card("Past Vendor Support", past, "Assets already unsupported", "⚠", "red")
with cols[1]: kpi_card("12-Month Exposure", exp, "Assets entering near-term refresh", "↻", "orange")
with cols[2]: kpi_card("Lifecycle Cost", cost, "Replacement cost in exposed estate", "$", "green")
with cols[3]: kpi_card("Largest Exposure", top_bu, "Business unit with highest unsupported volume", "◎", "purple")

section_card("Executive Interpretation", "Lifecycle exposure should be managed as a portfolio risk. Unsupported assets create vendor support gaps, audit exposure, operational instability, and increased remediation complexity. The priority is to sequence refresh activity by business criticality and risk concentration rather than by device age alone.")

if not bu.empty:
    chart_title("Unsupported Assets by Business Unit")
    insight("Ranks business units by assets already past vendor support. This helps leaders decide where refresh funding and remediation work should start.")
    bar_chart(topn(bu, "past_eol", 10), x="past_eol", y="Business_Unit", color="executive_risk_band", height=410)
if not by_type.empty:
    agg = by_type.groupby("Asset_Type", as_index=False).agg(assets=("assets", "sum"), replacement_cost=("replacement_cost", "sum"))
    chart_title("Lifecycle Exposure by Asset Type")
    insight("Shows which technology categories contribute most to lifecycle exposure. This separates endpoint risk from server, network, and storage risk.")
    bar_chart(topn(agg, "assets", 10), x="assets", y="Asset_Type", height=390)
