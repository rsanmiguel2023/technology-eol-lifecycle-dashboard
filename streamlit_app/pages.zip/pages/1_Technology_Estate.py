import streamlit as st
from ui_components import setup_page, hero, kpi_card, load_report, fmt_number, fmt_money, chart_title, insight, bar_chart, topn, section_card

setup_page("Technology Estate")
hero("Technology Estate", "Baseline view of the bank's managed technology footprint across device types, environments, and business areas.")

estate = load_report("technology_estate_summary.csv")
asset_type = load_report("eda_asset_type_distribution.csv")
bu = load_report("eda_business_unit_asset_distribution.csv")
region = load_report("eda_region_office_distribution.csv")

assets = fmt_number(estate["assets"].sum()) if not estate.empty and "assets" in estate.columns else "—"
prod = fmt_number(estate["production_assets"].sum()) if not estate.empty and "production_assets" in estate.columns else "—"
critical = fmt_number(estate["critical_assets"].sum()) if not estate.empty and "critical_assets" in estate.columns else "—"
cost = fmt_money(estate["replacement_cost"].sum()) if not estate.empty and "replacement_cost" in estate.columns else "—"

cols = st.columns(4)
with cols[0]: kpi_card("Managed Assets", assets, "All hardware and infrastructure assets", "▣", "blue")
with cols[1]: kpi_card("Production Assets", prod, "Assets supporting live environments", "●", "green")
with cols[2]: kpi_card("Critical Assets", critical, "Assets supporting critical services", "⚠", "red")
with cols[3]: kpi_card("Replacement Baseline", cost, "Estimated current replacement value", "$", "purple")

section_card("Executive Interpretation", "The estate baseline establishes the size and business dependency of the managed technology footprint before lifecycle, cyber, compliance, and refresh risk are calculated. This view helps leaders understand whether risk is concentrated in end-user computing, infrastructure, or specific business areas.")

if not asset_type.empty:
    chart_title("Technology Estate by Asset Type")
    insight("Shows how the managed estate is distributed across device and infrastructure types. This helps leaders see whether exposure is concentrated in end-user devices, servers, network infrastructure, or storage platforms.")
    col = "assets" if "assets" in asset_type.columns else asset_type.columns[-1]
    name = "Asset_Type" if "Asset_Type" in asset_type.columns else asset_type.columns[0]
    bar_chart(topn(asset_type, col, 10), x=col, y=name, height=410)
if not bu.empty:
    chart_title("Asset Distribution by Business Unit")
    insight("Compares the technology footprint across business units so leadership can understand where operational dependency is highest.")
    col = "assets" if "assets" in bu.columns else bu.columns[-1]
    name = "Business_Unit" if "Business_Unit" in bu.columns else bu.columns[0]
    bar_chart(topn(bu, col, 10), x=col, y=name, height=390)
