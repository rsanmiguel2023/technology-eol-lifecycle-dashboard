import streamlit as st
from ui_components import setup_page, hero, kpi_card, load_report, fmt_number, fmt_money, chart_title, insight, bar_chart, topn, section_card

setup_page("Refresh Planning")
hero("Refresh Planning", "Funding and sequencing view for past and near-end-of-life technology refresh demand.")

refresh = load_report("refresh_budget_planning_summary.csv")
gap = load_report("refresh_budget_gap_summary.csv")

assets = fmt_number(refresh["assets"].sum()) if not refresh.empty and "assets" in refresh.columns else "—"
cost = fmt_money(refresh["estimated_replacement_cost"].sum()) if not refresh.empty and "estimated_replacement_cost" in refresh.columns else "—"
peak_window = str(refresh.groupby("Refresh_Window")["estimated_replacement_cost"].sum().idxmax()) if not refresh.empty and "Refresh_Window" in refresh.columns else "—"
peak_cost = fmt_money(refresh.groupby("Refresh_Window")["estimated_replacement_cost"].sum().max()) if not refresh.empty and "Refresh_Window" in refresh.columns else "—"
cols = st.columns(4)
with cols[0]: kpi_card("Refresh Assets", assets, "Assets in refresh planning scope", "↻", "orange")
with cols[1]: kpi_card("Investment Need", cost, "Estimated replacement cost", "$", "green")
with cols[2]: kpi_card("Peak Window", peak_window, "Largest forecast period", "▲", "purple")
with cols[3]: kpi_card("Peak Cost", peak_cost, "Largest period cost", "$", "green")

section_card("Executive Interpretation", "Refresh planning should be managed as a multi-year portfolio. The objective is to prevent a backlog of unsupported assets, reduce unplanned remediation, and align funding decisions with business risk concentration.")

if not refresh.empty:
    win = refresh.groupby("Refresh_Window", as_index=False).agg(estimated_replacement_cost=("estimated_replacement_cost", "sum"), assets=("assets", "sum"))
    chart_title("Refresh Investment by Planning Window")
    insight("Shows the expected investment required by refresh window. This helps leadership smooth funding needs instead of reacting to large unplanned replacement waves.")
    bar_chart(win, x="estimated_replacement_cost", y="Refresh_Window", height=360)
    typ = refresh.groupby("Asset_Type", as_index=False).agg(estimated_replacement_cost=("estimated_replacement_cost", "sum"), assets=("assets", "sum"))
    chart_title("Refresh Cost by Asset Type")
    insight("Identifies which technology categories drive the largest refresh investment requirement.")
    bar_chart(topn(typ, "estimated_replacement_cost", 10), x="estimated_replacement_cost", y="Asset_Type", height=390)
