import streamlit as st
from ui_components import setup_page, hero, kpi_card, load_report, fmt_number, chart_title, insight, bar_chart, topn, section_card

setup_page("Compliance Risk")
hero("Compliance Risk", "Software lifecycle and version-level compliance exposure across the managed estate.")

sw = load_report("software_compliance_risk_summary.csv")
versions = load_report("compliance_software_versions_summary.csv")
if versions.empty:
    versions = sw.copy()

total_installs = fmt_number(sw["non_compliant_installs"].sum()) if not sw.empty and "non_compliant_installs" in sw.columns else "—"
distinct_assets = fmt_number(sw["distinct_assets"].sum()) if not sw.empty and "distinct_assets" in sw.columns else "—"
products = fmt_number(sw["Software_Name"].nunique()) if not sw.empty and "Software_Name" in sw.columns else "—"
status = str(sw["Software_Lifecycle_Status"].mode().iloc[0]) if not sw.empty and "Software_Lifecycle_Status" in sw.columns else "—"
cols = st.columns(4)
with cols[0]: kpi_card("Unsupported Installs", total_installs, "Software installations needing review", "⌘", "orange")
with cols[1]: kpi_card("Affected Assets", distinct_assets, "Distinct assets with exposure", "▣", "blue")
with cols[2]: kpi_card("Products in Scope", products, "Unique software products", "◇", "purple")
with cols[3]: kpi_card("Primary Status", status, "Common lifecycle status", "⚠", "red")

section_card("Executive Interpretation", "Software compliance risk is version-specific. The same product can have supported and unsupported versions across different devices, so remediation should target version-level exposure instead of product name alone.")

if not versions.empty:
    df = versions.copy()
    if "Software_Label" not in df.columns:
        df["Software_Label"] = df.get("Software_Name", "Software").astype(str) + " " + df.get("Version", "").astype(str)
    chart_title("Unsupported Software Versions")
    insight("Breaks down compliance exposure at the version level. This helps leaders prioritize software upgrades that reduce audit and security exposure fastest.")
    bar_chart(topn(df, "non_compliant_installs", 12), x="non_compliant_installs", y="Software_Label", height=460)
